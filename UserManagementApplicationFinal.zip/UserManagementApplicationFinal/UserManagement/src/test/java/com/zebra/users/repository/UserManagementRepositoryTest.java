package com.zebra.users.repository;

import com.zebra.users.model.UserManagement;
import com.zebra.users.tenantconfiguration.repository.DataSourceConfigRepository;
import lombok.Builder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;


@SpringBootTest
class UserManagementRepositoryTest {

    @Autowired
    private UserManagementRepository userManagementRepository;
    @Test
    void save() {
        UserManagement user = UserManagement.builder()
                .firstName("raja")
                .emailAddress("raja@gmail.com")
                .lastName("peddanna")
                .tenantId("tenant1")
                .build();
        userManagementRepository.save(user);
    }
}