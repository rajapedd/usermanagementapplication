package com.zebra.users.services;

import com.zebra.users.model.UserManagement;

import java.util.List;

public interface UserManagementSearchService {
    List<UserManagement> searchUsers(String query);
    List<UserManagement>  findUsersWithAttributes(String firstName,String lastName , String emailAddress);
}
