package com.zebra.users.controller;

import com.zebra.users.model.UserManagement;
import com.zebra.users.services.UserManagementSearchService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@Slf4j
@RestController
@RequestMapping("/users")
public class UserManagementSearchController {

    @Autowired
    private UserManagementSearchService userManagementSearchService;

    @GetMapping("/search")
    public ResponseEntity<List<UserManagement>> searchUsers(@RequestParam("query") String query){
        log.info("searching query :: "+query);
        return ResponseEntity.ok(userManagementSearchService.searchUsers(query));
    }

    @GetMapping("/searchWithAttributes")
    public ResponseEntity<List<UserManagement>> searchUsersWithAttributes(@RequestParam("firstName") String firstName,@RequestParam("lastName") String lastName,@RequestParam("emailAddress") String emailAddress){
        log.info("searching With Attributes firstName :: "+firstName);
        log.info("searching With Attributes lastName :: "+lastName);
        log.info("searching With Attributes emailAddress :: "+emailAddress);
        return ResponseEntity.ok(userManagementSearchService.findUsersWithAttributes(firstName, lastName, emailAddress));
    }

}
