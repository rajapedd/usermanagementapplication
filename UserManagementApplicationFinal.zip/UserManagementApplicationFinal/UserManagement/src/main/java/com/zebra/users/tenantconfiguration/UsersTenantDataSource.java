package com.zebra.users.tenantconfiguration;


import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import com.zebra.users.tenantconfiguration.repository.DataSourceConfigRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
//@Component
public class UsersTenantDataSource implements Serializable {

    private HashMap<String, DataSource> dataSources = new HashMap<>();

    @Autowired
    private DataSourceConfigRepository configRepo;

    public DataSource getDataSource(String name) {
        if (dataSources.get(name) != null) {
            return dataSources.get(name);
        }
        System.out.println("DB name=="+name);
        DataSource dataSource = createDataSource(name);
        if (dataSource != null) {
            dataSources.put(name, dataSource);
        }
        return dataSource;
    }

//    @PostConstruct
    public Map<String, DataSource> getAll() {
        List<DataSourceConfigurations> configList = configRepo.findAll();
        System.out.println("configList==>"+configList);
        Map<String, DataSource> result = new HashMap<>();
        for (DataSourceConfigurations config : configList) {
            DataSource dataSource = getDataSource(config.getName());
            result.put(config.getName(), dataSource);
        }
        System.out.println("Map Values ==>"+result);
        return result;
    }

    private DataSource createDataSource(String name) {
        DataSourceConfigurations config = configRepo.findByName(name);
        log.info("Config Details :: "+config);
        log.info("Config Name:: "+name);
        if (config != null) {
            HikariConfig configHikari = new HikariConfig();
            configHikari.setDriverClassName(config.getDriverClassName());
            configHikari.setJdbcUrl(config.getUrl());
            configHikari.setUsername(config.getUsername());
            configHikari.setPassword(config.getPassword());
            log.info("Config ds :: "+configHikari);
            return new HikariDataSource(configHikari);
        }
        return null;
    }
}
