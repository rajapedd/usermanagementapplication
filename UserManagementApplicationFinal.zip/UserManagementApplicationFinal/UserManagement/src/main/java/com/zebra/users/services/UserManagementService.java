package com.zebra.users.services;

import com.zebra.users.dto.UserDTO;
import com.zebra.users.model.UserManagement;

import java.util.List;
import java.util.Optional;

public interface UserManagementService {
   // String saveUser(UserManagement userDTO);

    UserManagement saveUser(UserManagement userObject);
    UserManagement updateUser(UserManagement userObject);
    void deleteUserById(Long id);
    List<UserManagement> findAllUsers();
    Optional<UserManagement> findUserById(Long id);
    List<UserManagement> findUserByFirstName(String firstName);
    List<UserManagement> findUserByFirstNameContaining(String name);
    List<UserManagement> findUserByFirstNameAndLastName(String firstName,
                                              String lastName);
    List<UserManagement> findUserByEmailAddress(String emailId);




}
