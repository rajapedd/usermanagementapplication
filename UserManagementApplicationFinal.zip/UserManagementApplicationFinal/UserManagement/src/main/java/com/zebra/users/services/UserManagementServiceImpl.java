package com.zebra.users.services;

import com.zebra.users.model.UserManagement;
import com.zebra.users.repository.UserManagementRepository;
import com.zebra.users.tenantconfiguration.interceptor.UserTenantContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;


@Service
public class UserManagementServiceImpl implements UserManagementService{

  @Autowired
  private UserManagementRepository userManagementRepository;

  @Override
  public UserManagement saveUser(UserManagement userObject) {
   String tenantValue = UserTenantContext.getCurrentTenant();
    System.out.println("tenantValue on Save==>"+tenantValue);
    if( null != tenantValue){
      userObject.setTenantId(tenantValue);
    }
    UserManagement createdUser=userManagementRepository.save(userObject);
    return createdUser;
  }

  @Override
  public UserManagement updateUser(UserManagement userObject) {
    String tenantValue = UserTenantContext.getCurrentTenant();
    System.out.println("tenantValue On update==>"+tenantValue);
    if( null != tenantValue){
      userObject.setTenantId(tenantValue);
    }
    UserManagement updatedUser=userManagementRepository.save(userObject);
    return updatedUser;
  }

  @Override
  public void deleteUserById(Long id) {
    String tenantValue = UserTenantContext.getCurrentTenant();
    System.out.println("tenantValue On delete==>"+tenantValue);
    userManagementRepository.deleteById(id);
  }

  @Override
  public List<UserManagement> findAllUsers() {
    List<UserManagement> listOfUsers = userManagementRepository.findAll();
    return listOfUsers;
  }

  @Override
  public Optional<UserManagement> findUserById(Long id) {
    Optional<UserManagement> userManagement = userManagementRepository.findById(id);
    return userManagement;
  }

  @Override
  public List<UserManagement> findUserByFirstName(String firstName) {
    List<UserManagement> lisOfUsersWithFirstName= userManagementRepository.findByFirstName(firstName);
    return lisOfUsersWithFirstName;
  }

  @Override
  public List<UserManagement> findUserByFirstNameContaining(String name) {
    List<UserManagement> lisOfUsersWithFirstName= userManagementRepository.findByFirstNameContaining(name);
    return lisOfUsersWithFirstName;
  }

  @Override
  public List<UserManagement> findUserByFirstNameAndLastName(String firstName, String lastName) {
    List<UserManagement> userManagement = userManagementRepository.findByFirstNameAndLastName(firstName, lastName);
    return userManagement;
  }

  @Override
  public List<UserManagement> findUserByEmailAddress(String emailId) {
    List<UserManagement> userManagementWithMailId = userManagementRepository.findByEmailAddress(emailId);
    return userManagementWithMailId;
  }




}
