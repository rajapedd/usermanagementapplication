package com.zebra.users.bulkinsertconfig;

import com.zebra.users.model.UserManagement;
import com.zebra.users.tenantconfiguration.interceptor.UserTenantContext;
import org.springframework.batch.item.ItemProcessor;

public class UserProcessor implements ItemProcessor<UserManagement,UserManagement> {

    @Override
    public UserManagement process(UserManagement user) throws Exception {
        String tenantValue = UserTenantContext.getCurrentTenant();
        System.out.println("tenantValue on process==>"+tenantValue);
        if(null != tenantValue){
            user.setTenantId(tenantValue);
        }


        if(user.getTenantId().equals(tenantValue)) {
            user.setTenantId(tenantValue);
            return user;
        }else{
            return null;
        }
    }
}
