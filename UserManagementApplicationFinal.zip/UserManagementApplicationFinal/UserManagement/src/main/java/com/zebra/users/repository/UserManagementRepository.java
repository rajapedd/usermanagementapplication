package com.zebra.users.repository;

import com.zebra.users.dto.UserDTO;
import com.zebra.users.model.UserManagement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface UserManagementRepository extends JpaRepository<UserManagement,Long> {

        List<UserManagement> findAll();
        Optional<UserManagement> findById(Long id);
        List<UserManagement> findByFirstName(String firstName);
        List<UserManagement> findByFirstNameContaining(String name);
        List<UserManagement> findByFirstNameAndLastName(String firstName,String lastName);
        List<UserManagement> findByEmailAddress(String emailId);
        UserManagement save(UserManagement userObject);
        void deleteById(Long id);


        @Query(value = "SELECT * FROM users u WHERE " +
                "u.first_name LIKE CONCAT('%', :query,'%')" +
                "or u.last_name LIKE CONCAT('%', :query,'%')" +
                "or u.email_address LIKE CONCAT('%', :query,'%')",nativeQuery = true )
        List<UserManagement> searchUsers(String query);



        List<UserManagement> findByFirstNameOrLastNameOrEmailAddress(String firstName,String lastName,String emailAddress);

}
