package com.zebra.users.tenantconfiguration.interceptor;

import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.springframework.stereotype.Component;

@Component
public class UsersTenantSchemaResolver implements CurrentTenantIdentifierResolver {

    private String defaultTenant ="tenant1";

    @Override
    public String resolveCurrentTenantIdentifier() {
        String t =  UserTenantContext.getCurrentTenant();
        if(t!=null){
            return t;
        } else {
            return defaultTenant;
        }
    }

    @Override
    public boolean validateExistingCurrentSessions() {
        return true;
    }
}

