package com.zebra.users.tenantconfiguration.repository;

import com.zebra.users.tenantconfiguration.DataSourceConfigurations;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface DataSourceConfigRepository extends JpaRepository<DataSourceConfigurations, Long> {
    DataSourceConfigurations findByName(String name);

    List<DataSourceConfigurations> findAll();
}
