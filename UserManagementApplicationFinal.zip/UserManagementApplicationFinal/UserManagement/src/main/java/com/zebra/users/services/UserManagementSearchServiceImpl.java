package com.zebra.users.services;

import com.zebra.users.model.UserManagement;
import com.zebra.users.repository.UserManagementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserManagementSearchServiceImpl implements UserManagementSearchService{

    @Autowired
    private UserManagementRepository userManagementRepository;
    @Override
    public List<UserManagement> searchUsers(String query) {
        List<UserManagement> users=  userManagementRepository.searchUsers(query);
        return users;
    }
    @Override
    public List<UserManagement> findUsersWithAttributes(String firstName, String lastName, String emailAddress) {
        List<UserManagement> usersList = userManagementRepository.findByFirstNameOrLastNameOrEmailAddress(firstName,lastName,emailAddress);
        return usersList;
    }
}
