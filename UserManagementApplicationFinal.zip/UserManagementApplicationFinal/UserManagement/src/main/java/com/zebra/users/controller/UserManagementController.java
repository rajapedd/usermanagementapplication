package com.zebra.users.controller;


import com.zebra.users.model.UserManagement;
import com.zebra.users.services.UserManagementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;


@Slf4j
@RestController
public class UserManagementController {
    @Autowired
    private UserManagementService userManagementService;

   @PostMapping(value ="/createUser")
   @RequestMapping(value = "/createUser", method = RequestMethod.POST)
    public ResponseEntity<UserManagement> createUser(@RequestBody UserManagement userObject) {
        return ResponseEntity.ok(userManagementService.saveUser(userObject));
    }
    @PutMapping(value ="/updateUser")
    public ResponseEntity<?> updateUser(@RequestBody UserManagement userObject) {
        return ResponseEntity.ok(userManagementService.updateUser(userObject));
    }

    @GetMapping(value ="/getUsersList")
    public List<UserManagement> getUsers() {
        List<UserManagement> listOfUsers= userManagementService.findAllUsers();
        return listOfUsers;
    }

    @GetMapping(value ="/getUserWithEmailId/{emailId}")
    public List<UserManagement> getUserWithEmail(@PathVariable String emailId) {
        List<UserManagement> userWithEmail= userManagementService.findUserByEmailAddress(emailId);
        return userWithEmail;
    }

    @GetMapping(value ="/getFirstNameStartsWith/{firstNameStartsWith}")
    public List<UserManagement> getUserFirstNameStartsWith(@PathVariable String firstNameStartsWith) {
        List<UserManagement> userFirstNameStartsWith= userManagementService.findUserByFirstNameContaining(firstNameStartsWith);
        return userFirstNameStartsWith;
    }

    @GetMapping(value ="/getUserByFirstNameAndLastName/{firstName}/{lastName}")
    public List<UserManagement> findUserByFirstNameAndLastName(@PathVariable String firstName,@PathVariable String lastName) {
        List<UserManagement> userByFirstNameAndLastName= userManagementService.findUserByFirstNameAndLastName(firstName,lastName);
        return userByFirstNameAndLastName;
    }

    @DeleteMapping(value ="/deleteUserById/{userId}")
    public ResponseEntity<?> deleteUser(@PathVariable Long userId) {
        userManagementService.deleteUserById(userId);
        return ResponseEntity.ok("User Deleted Successfully...!!!");
    }

    @GetMapping(value ="/getUserById/{Id}")
    public Optional<UserManagement> getUserById(@PathVariable Long Id) {
        Optional<UserManagement> userWithId= userManagementService.findUserById(Id);
        return userWithId;
    }

    @GetMapping(value ="/getUserByFirstName/{firstName}")
    public List<UserManagement> getUserByFirstName(@PathVariable String firstName) {
        List<UserManagement> usersWithFirstName= userManagementService.findUserByFirstName(firstName);
        return usersWithFirstName;
    }

    @GetMapping(value="/ping")
    public void healthCheck(){
        log.info("User Service is Running");
    }
}
